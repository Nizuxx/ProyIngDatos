/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.Date;

public class Campaign {
    private int ID;
    private String nombre;
    private float presupuesto;
    private Date fecha_inicio;
    private Date fecha_fin;
    private String plan_accion;
    private int KPI_real;
    private int KPI_objetivo;
    private int codigo_crm;

    public Campaign(int ID, String nombre, float presupuesto, Date fecha_inicio, Date fecha_fin, String plan_accion, int KPI_real, int KPI_objetivo, int codigo_crm) {
        this.ID = ID;
        this.nombre = nombre;
        this.presupuesto = presupuesto;
        this.fecha_inicio = fecha_inicio;
        this.fecha_fin = fecha_fin;
        this.plan_accion = plan_accion;
        this.KPI_real = KPI_real;
        this.KPI_objetivo = KPI_objetivo;
        this.codigo_crm = codigo_crm;
    }
    
    public Campaign(){
        
    }


    public int getID() {
        return ID;
    }

    public String getNombre() {
        return nombre;
    }

    public float getPresupuesto() {
        return presupuesto;
    }

    public Date getFecha_inicio() {
        return fecha_inicio;
    }

    public Date getFecha_fin() {
        return fecha_fin;
    }

    public String getPlan_accion() {
        return plan_accion;
    }

    public int getKPI_objetivo() {
        return KPI_objetivo;
    }

    public int getCodigo_crm() {
        return codigo_crm;
    }

    public int getKPI_real() {
        return KPI_real;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPresupuesto(float presupuesto) {
        this.presupuesto = presupuesto;
    }

    public void setFecha_inicio(Date fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public void setFecha_fin(Date fecha_fin) {
        this.fecha_fin = fecha_fin;
    }

    public void setPlan_accion(String plan_accion) {
        this.plan_accion = plan_accion;
    }

    public void setKPI_real(int KPI_real) {
        this.KPI_real = KPI_real;
    }

    public void setKPI_objetivo(int KPI_objetivo) {
        this.KPI_objetivo = KPI_objetivo;
    }

    public void setCodigo_crm(int codigo_crm) {
        this.codigo_crm = codigo_crm;
    }
    
    
    
    
    @Override
    public String toString() {
        return "Campaign{" + "ID= " + ID + ", nombre= " + nombre + ", presupuesto= " + presupuesto + ", fecha_inicio= " + fecha_inicio + ", fecha_fin= " + fecha_fin + ", plan_accion= " + plan_accion + ", KPI_real= " + KPI_real + ", KPI_objetivo= " + KPI_objetivo + ", codigo_crm= " + codigo_crm + '}';
    }
    
    
    
}




