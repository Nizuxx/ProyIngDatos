/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package view;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;
import manage.ClientesCampaignDB;
import tablas.ClienteCampaign;

/**
 *
 * @author nzuri
 */
public class ListaClientesCampaignIU extends javax.swing.JFrame {

    
    ArrayList<ClienteCampaign> listaClientesCampaign;
    ClientesCampaignDB db = new ClientesCampaignDB();
    /**
     */
    public ListaClientesCampaignIU() {
        initComponents();
    }
    
    



  
    public void ListarDatosClienteCampaign() throws Exception{
        listaClientesCampaign = db.obtenerClientesCampaign();
        DefaultTableModel tb = (DefaultTableModel) tablaListaClienteCampaign.getModel();
        for(ClienteCampaign cc: listaClientesCampaign){
             tb.addRow(new Object[]{cc.getnombre_cliente(),cc.getDNI(), cc.getDireccion(), cc.getTelefono(), cc.getCorreo(), cc.getFecha_nac(), cc.getIngresos(), cc.getScore_crediticio(), cc.getID(), cc.getPlan_accion(), cc.getPresupuesto()});
        }
        
    }
    
    public void LimpiarFormularioCC(){
        DefaultTableModel tb = (DefaultTableModel) tablaListaClienteCampaign.getModel();
        for(int i = tb.getRowCount()-1; i > 0; i--){
            tb.removeRow(i);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tablaListaClienteCampaign = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        btnListarClientesCampaign = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tablaListaClienteCampaign.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NOMBRE_CLIENTE", "CLIENT_DNI", "DIRECCION", "TELEFONO", "CORREO", "FECHA_NACIMIENTO", "INGRESOS", "SCORE_CREDITICIO", "ID_CAMPAIGN", "PLAN_ACCION", "PRESUPUESTO"
            }
        ));
        jScrollPane1.setViewportView(tablaListaClienteCampaign);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, 811, 220));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Ver Cliente por Campaña");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 90, -1, -1));

        btnListarClientesCampaign.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/9004778_menu_list_navigation_options_icon.png"))); // NOI18N
        btnListarClientesCampaign.setText("Listar");
        btnListarClientesCampaign.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListarClientesCampaignActionPerformed(evt);
            }
        });
        getContentPane().add(btnListarClientesCampaign, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 100, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/BCP-LOGO.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 990, 580));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnListarClientesCampaignActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListarClientesCampaignActionPerformed
        try {
            ListarDatosClienteCampaign();
        } catch (Exception ex) {
            Logger.getLogger(ListaClientesCampaignIU.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnListarClientesCampaignActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ListaClientesCampaignIU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ListaClientesCampaignIU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ListaClientesCampaignIU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ListaClientesCampaignIU.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ListaClientesCampaignIU().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnListarClientesCampaign;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaListaClienteCampaign;
    // End of variables declaration//GEN-END:variables
}
