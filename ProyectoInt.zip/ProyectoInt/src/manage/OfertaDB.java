/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manage;

import conexion.jdbcutil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import tablas.Oferta;

public class OfertaDB {
    public ArrayList<Oferta> obtenerOfertas() throws Exception{
        ArrayList<Oferta> listaOfertas = new ArrayList<>();        
        Connection conn = jdbcutil.getConnection();
        String sql = "SELECT * FROM OFFER";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            int codigo = rs.getInt("CODIGO_OFERTA");
            Float monto = rs.getFloat("MONTO");
            int plazo = rs.getInt("PLAZO");
            int estado = rs.getInt("ESTADO");
            Float tasa = rs.getFloat("TASA");
            int evento = rs.getInt("EVENTO");
            int campaign_id = rs.getInt("CAMPAIGN_ID");
            Oferta of = new Oferta(codigo, monto,plazo, estado, tasa, evento, campaign_id);
            listaOfertas.add(of);
        }
        rs.close();
        pst.close();
        conn.close();
        return listaOfertas;
    }
}
