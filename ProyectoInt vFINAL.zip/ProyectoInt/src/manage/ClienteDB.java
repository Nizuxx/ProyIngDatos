/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manage;

import conexion.jdbcutil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import tablas.Cliente;

/**
 *
 * @author nzuri
 */
public class ClienteDB {
    public ArrayList<Cliente> obtenerClientes() throws Exception{
        ArrayList<Cliente> listaClientes = new ArrayList<>();        
        Connection conn = jdbcutil.getConnection();
        String sql = "SELECT * FROM CLIENTE";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            String nombre_cliente = rs.getString("NOMBRE_CLIENTE");
            int DNI = rs.getInt("CLIENT_DNI");
            String direccion = rs.getString("DIRECCION");
            String telefono = rs.getString("TELEFONO");
            String correo = rs.getString("Correo");
            Date fecha_nac = rs.getDate("FECHA_NAC");
            Float ingresos = rs.getFloat("INGRESOS");
            int score_crediticio = rs.getInt("SCORE_CREDITICIO");
            Cliente c = new Cliente(nombre_cliente,DNI,direccion, telefono, correo, fecha_nac, ingresos, score_crediticio);
            listaClientes.add(c);
        }
        rs.close();
        pst.close();
        conn.close();
        return listaClientes;
    }
    
    
    public void insertarClientes(Cliente cliente) throws Exception{
        Connection conn = jdbcutil.getConnection();
        String sql = "INSERT INTO CLIENTE(NOMBRE_CLIENTE, CLIENT_DNI, DIRECCION, TELEFONO, CORREO, FECHA_NAC, INGRESOS,SCORE_CREDITICIO) VALUES(?,?,?,?,?,?,?,?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, cliente.getNombre_cliente());
        pst.setInt(2, cliente.getDNI());
        pst.setString(3, cliente.getDireccion());
        pst.setString(4, cliente.getTelefono());
        pst.setString(5, cliente.getCorreo());
        java.util.Date fechaNacimiento = cliente.getFecha_nac();
        java.sql.Date sqlFechaNacimiento = new java.sql.Date(fechaNacimiento.getTime());
        pst.setDate(6, sqlFechaNacimiento);
        pst.setFloat(7, cliente.getIngresos());
        pst.setInt(8, cliente.getScore_crediticio());
        pst.executeUpdate();
        pst.close();
        conn.close();
    } 
}
