/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manage;

import conexion.jdbcutil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import tablas.Cliente;
import tablas.Verificacion;

/**
 *
 * @author nzuri
 */
public class VerificacionDB {
    public ArrayList<Verificacion> obtenerVerificaciones() throws Exception{
        ArrayList<Verificacion> listaVerificaciones = new ArrayList<>();        
        Connection conn = jdbcutil.getConnection();
        String sql = "SELECT * FROM VERIFICATION";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            int cod_verificacion = rs.getInt("VERIFICATION_CODE");
            String descripcion = rs.getString("DESCRIPCION");
           
            Date Fecha_Inicio = rs.getDate("FECHA_INICIO");
            Date Fecha_Fin = rs.getDate("Fecha_FIN");
            int Estado=rs.getInt("ESTADO");
            String Sugerencia = rs.getString("SUGERENCIA");
            int cod_advisor=rs.getInt("CODIGO_ADVISOR");
           Verificacion v = new Verificacion(cod_verificacion,descripcion,Fecha_Inicio,Fecha_Fin,Estado,Sugerencia,cod_advisor);
            listaVerificaciones.add(v);
        }
        rs.close();
        pst.close();
        conn.close();
        return listaVerificaciones;
    }
    
    
    public void AñadirVerificacion(Verificacion verificacion) throws Exception{
        Connection conn = jdbcutil.getConnection();
        String sql = "INSERT INTO VERIFICACION(VERIFICATION_CODE,DESCRIPCION,FECHA_INICIO,FECHA_FIN,ESTADO,SUGERENCIA,CODIGO_ADVISOR) VALUES(?,?,?,?,?,?,?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, verificacion.getCode());
        pst.setString(2, verificacion.getDescripcion());
        java.util.Date fechaInicio = verificacion.getFecha_inicio();
        java.sql.Date sqlFechaInicio = new java.sql.Date(fechaInicio.getTime());
        pst.setDate(3, sqlFechaInicio);
        java.util.Date fechaFin = verificacion.getFecha_fin();
        java.sql.Date sqlFechaFin = new java.sql.Date(fechaFin.getTime());
        pst.setDate(4, sqlFechaFin);
        pst.setInt(5, verificacion.getEstado());
        pst.setString(6, verificacion.getSugerencia());
        pst.setInt(7,verificacion.getCodigo_advisor());
        
        pst.executeUpdate();
        pst.close();
        conn.close();
    } 
}
