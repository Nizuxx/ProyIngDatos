/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manage;

import conexion.jdbcutil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import tablas.ClienteOferta;

/**
 *
 * @author nzuri
 */
public class ClienteOfertaDB {
    public ArrayList<ClienteOferta> obtenerClientesOfertas() throws Exception{
        ArrayList<ClienteOferta> listaClientesOferta = new ArrayList<>();        
        Connection conn = jdbcutil.getConnection();
        String sql = "SELECT CODIGO_OFERTA, CLIENT_DNI, SCORE_CREDITICIO, INGRESOS, PLAZO, MONTO, TASA "
                + "FROM CLIENT_OFFER INNER JOIN CLIENTE USING(CLIENT_DNI)"
                + "INNER JOIN OFFER USING(CODIGO_OFERTA)";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            int codigo_oferta = rs.getInt("CODIGO_OFERTA");
            int DNI = rs.getInt("CLIENT_DNI");
            int score_crediticio = rs.getInt("SCORE_CREDITICIO");
            Float ingresos = rs.getFloat("INGRESOS");
            int plazo = rs.getInt("PLAZO");
            Float monto = rs.getFloat("MONTO");
            Float tasa = rs.getFloat("TASA");
            
            
            ClienteOferta co = new ClienteOferta(codigo_oferta, DNI, score_crediticio, ingresos, plazo, monto, tasa);
            listaClientesOferta.add(co);
        }
        rs.close();
        pst.close();
        conn.close();
        return listaClientesOferta;
    }
}
