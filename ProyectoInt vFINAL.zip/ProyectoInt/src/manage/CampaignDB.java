/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manage;

import conexion.jdbcutil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import tablas.Campaign;

public class CampaignDB {
    public ArrayList<Campaign> obtenerCampaign() throws Exception{
        ArrayList<Campaign> listaCampaigns = new ArrayList<>();
        Connection conn = jdbcutil.getConnection();
        String sql = "SELECT * FROM CAMPAIGN";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            int ID = rs.getInt("CAMPAIGN_ID");
            String nombre = rs.getString("NOMBRE_CAMPAIGN");
            Float presupuesto = rs.getFloat("PRESUPUESTO");
            Date fecha_inicio = rs.getDate("FECHA_INICIO");
            Date fecha_fin = rs.getDate("FECHA_FIN");
            String plan_accion = rs.getString("PLAN_ACCION");
            int KPI_real = rs.getInt("KPI_REAL");
            int KPI_objetivo = rs.getInt("KPI_objetivo");
            int codigo_crm = rs.getInt("CODIGO_CRM");
            Campaign ca = new Campaign(ID, nombre, presupuesto, fecha_inicio, fecha_fin, plan_accion, KPI_real, KPI_objetivo, codigo_crm);
            listaCampaigns.add(ca);
        }
        rs.close();
        pst.close();
        conn.close();
        return listaCampaigns;
    }
    
    public void insertarCampaigns(Campaign campaign) throws Exception{
        Connection conn = jdbcutil.getConnection();
        String sql = "INSERT INTO CAMPAIGN(CAMPAIGN_ID, NOMBRE_CAMPAIGN, PRESUPUESTO, FECHA_INICIO, FECHA_FIN, PLAN_ACCION, KPI_REAL,KPI_OBJETIVO,CODIGO_CRM) VALUES(?,?,?,?,?,?,?,?,?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, campaign.getID());
        pst.setString(2, campaign.getNombre());
        pst.setFloat(3, campaign.getPresupuesto());
        java.util.Date fechaInicio = campaign.getFecha_inicio();
        java.sql.Date sqlFechaInicio = new java.sql.Date(fechaInicio.getTime());
        pst.setDate(4, sqlFechaInicio);
        java.util.Date fechaFin = campaign.getFecha_fin();
        java.sql.Date sqlFechaFin = new java.sql.Date(fechaFin.getTime());
        pst.setDate(5, sqlFechaFin);
        pst.setString(6, campaign.getPlan_accion());
        pst.setInt(7, campaign.getKPI_real());
        pst.setInt(8, campaign.getKPI_objetivo());
        pst.setInt(9, campaign.getCodigo_crm());
        

        pst.executeUpdate();
        pst.close();
        conn.close();
    }     
}
