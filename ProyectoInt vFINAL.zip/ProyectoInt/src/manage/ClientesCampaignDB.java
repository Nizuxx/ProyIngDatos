/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package manage;

import conexion.jdbcutil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import tablas.ClienteCampaign;

public class ClientesCampaignDB {
    
    public ArrayList<ClienteCampaign> obtenerClientesCampaign() throws Exception{
        ArrayList<ClienteCampaign> listaClientesCampaign = new ArrayList<>();        
        Connection conn = jdbcutil.getConnection();
        String sql = "SELECT NOMBRE_CLIENTE, CLIENT_DNI, DIRECCION, TELEFONO, CORREO, FECHA_NAC, INGRESOS, SCORE_CREDITICIO, CAMPAIGN_ID, PLAN_ACCION, PRESUPUESTO "
                + "FROM CAMPAIGN_CLIENTE INNER JOIN CLIENTE USING(CLIENT_DNI)"
                + " INNER JOIN CAMPAIGN USING(CAMPAIGN_ID)";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        while(rs.next()){
            String nombre_cliente = rs.getString("NOMBRE_CLIENTE");
            int DNI = rs.getInt("CLIENT_DNI");
            String direccion = rs.getString("DIRECCION");
            String telefono = rs.getString("TELEFONO");
            String correo = rs.getString("CORREO");
            Date fecha_nac = rs.getDate("FECHA_NAC");
            Float ingresos = rs.getFloat("INGRESOS");
            int score_crediticio = rs.getInt("SCORE_CREDITICIO");
            int ID = rs.getInt("CAMPAIGN_ID");
            String plan_accion = rs.getString("PLAN_ACCION");
            Float presupuesto = rs.getFloat("PRESUPUESTO");
            
            ClienteCampaign cc = new ClienteCampaign(nombre_cliente,DNI, direccion, telefono, correo, fecha_nac, ingresos, score_crediticio, ID, plan_accion, presupuesto);
            listaClientesCampaign.add(cc);
        }
        rs.close();
        pst.close();
        conn.close();
        return listaClientesCampaign;
    }
}
