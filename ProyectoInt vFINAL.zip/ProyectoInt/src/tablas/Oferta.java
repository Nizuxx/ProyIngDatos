/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

public class Oferta {
    private int codigo;
    private float monto;
    private int plazo;
    private int estado;
    private float tasa;
    private int evento;
    private int campaign_id;

    public Oferta(int codigo, float monto, int plazo, int estado, float tasa, int evento, int campaign_id) {
        this.codigo = codigo;
        this.monto = monto;
        this.plazo = plazo;
        this.estado = estado;
        this.tasa = tasa;
        this.evento = evento;
        this.campaign_id = campaign_id;
    }

    
    public int getCodigo() {
        return codigo;
    }

    public float getMonto() {
        return monto;
    }

    public int getEstado() {
        return estado;
    }

    public float getTasa() {
        return tasa;
    }

    public int getEvento() {
        return evento;
    }

    public int getCampaign_id() {
        return campaign_id;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public void setEstado(int estado) {
        this.estado = estado;
    }

    public void setTasa(float tasa) {
        this.tasa = tasa;
    }

    public void setEvento(int evento) {
        this.evento = evento;
    }

    public void setCampaign_id(int campaign_id) {
        this.campaign_id = campaign_id;
    }

    public int getPlazo() {
        return plazo;
    }

    public void setPlazo(int plazo) {
        this.plazo = plazo;
    }

    @Override
    public String toString() {
        return "Oferta{" + "codigo=" + codigo + ", monto=" + monto + ", plazo=" + plazo + ", estado=" + estado + ", tasa=" + tasa + ", evento=" + evento + ", campaign_id=" + campaign_id + '}';
    }
    
    

    
}
