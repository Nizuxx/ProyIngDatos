/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

/**
 *
 * @author nzuri
 */
public class Usuario {
    private int cod_user;
    private String nombre;
    private String correo;
    private String passw;
    private int area;

    public Usuario(int cod_user, String nombre, String correo, String passw, int area) {
        this.cod_user = cod_user;
        this.nombre = nombre;
        this.correo = correo;
        this.passw = passw;
        this.area = area;
    }

    public int getCod_user() {
        return cod_user;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public String getPassw() {
        return passw;
    }

    public int getArea() {
        return area;
    }
    
    @Override
    public String toString(){
        return cod_user + " " + nombre + " " + correo + " " + passw + " " + area + " ";
    }
    
}


