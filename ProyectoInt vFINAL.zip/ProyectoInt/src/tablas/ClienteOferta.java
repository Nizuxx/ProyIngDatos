/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

/**
 *
 * @author nzuri
 */
public class ClienteOferta {
    private int codigo_oferta;
    private int DNI;
    private int score_crediticio;
    private float ingresos;
    private int plazo;
    private float monto;
    private float tasa;

    public ClienteOferta(int codigo_oferta, int DNI, int score_crediticio, float ingresos, int plazo, float monto, float tasa) {
        this.codigo_oferta = codigo_oferta;
        this.DNI = DNI;
        this.score_crediticio = score_crediticio;
        this.ingresos = ingresos;
        this.plazo = plazo;
        this.monto = monto;
        this.tasa = tasa;
    }

    public int getCodigo_oferta() {
        return codigo_oferta;
    }

    public void setCodigo_oferta(int codigo_oferta) {
        this.codigo_oferta = codigo_oferta;
    }

    public int getDNI() {
        return DNI;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public int getScore_crediticio() {
        return score_crediticio;
    }

    public void setScore_crediticio(int score_crediticio) {
        this.score_crediticio = score_crediticio;
    }

    public float getIngresos() {
        return ingresos;
    }

    public void setIngresos(float ingresos) {
        this.ingresos = ingresos;
    }

    public int getPlazo() {
        return plazo;
    }

    public void setPlazo(int plazo) {
        this.plazo = plazo;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public float getTasa() {
        return tasa;
    }

    public void setTasa(float tasa) {
        this.tasa = tasa;
    }

   
    
   
    
    
}
