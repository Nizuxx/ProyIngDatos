/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.Date;


public class Verificacion {
    private int code;
    private String descripcion;
    private Date fecha_inicio;
    private Date fecha_fin;
    private int estado;
    private String sugerencia;
    private int codigo_advisor;

    public Verificacion(int code, String descripcion, Date fecha_inicio, Date fecha_fin, int estado, String sugerencia, int codigo_advisor) {
        this.code = code;
        this.descripcion = descripcion;
        this.fecha_inicio = fecha_inicio;
        this.fecha_fin = fecha_fin;
        this.estado = estado;
        this.sugerencia = sugerencia;
        this.codigo_advisor = codigo_advisor;
    }

    public int getCode() {
        return code;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Date getFecha_inicio() {
        return fecha_inicio;
    }

    public Date getFecha_fin() {
        return fecha_fin;
    }


    public int getEstado() {
        return estado;
    }

    public String getSugerencia() {
        return sugerencia;
    }

    public int getCodigo_advisor() {
        return codigo_advisor;
    }

    @Override
    public String toString() {
        return "Verificacion{" + "code=" + code + ", descripcion=" + descripcion + ", fecha_inicio=" + fecha_inicio + ", fecha_fin=" + fecha_fin +  ", estado=" + estado + ", sugerencia=" + sugerencia + ", codigo_advisor=" + codigo_advisor + '}';
    }
    
    
    
}

