/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.Date;

public class ClienteCampaign {
    private int DNI;
    private String nombre_cliente;
    private String direccion;
    private String telefono;
    private String correo;
    private Date fecha_nac;
    private float ingresos;
    private int score_crediticio;
    private int ID;
    private String plan_accion;
    private float presupuesto;

    public ClienteCampaign(String nombre_cliente, int DNI, String direccion, String telefono, String correo, Date fecha_nac, float ingresos, int score_crediticio, int ID, String plan_accion, float presupuesto) {
        this.nombre_cliente = nombre_cliente;
        this.DNI = DNI;
        this.direccion = direccion;
        this.telefono = telefono;
        this.correo = correo;
        this.fecha_nac = fecha_nac;
        this.ingresos = ingresos;
        this.score_crediticio = score_crediticio;
        this.ID = ID;
        this.plan_accion = plan_accion;
        this.presupuesto = presupuesto;
    }

    public int getDNI() {
        return DNI;
    }

    public String getnombre_cliente() {
        return nombre_cliente;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public Date getFecha_nac() {
        return fecha_nac;
    }

    public float getIngresos() {
        return ingresos;
    }

    public int getScore_crediticio() {
        return score_crediticio;
    }

    public int getID() {
        return ID;
    }

    public String getPlan_accion() {
        return plan_accion;
    }

    public float getPresupuesto() {
        return presupuesto;
    }

    @Override
    public String toString() {
        return "ClienteCampaign{" + "DNI=" + DNI + ", nombre_cliente=" + nombre_cliente + ", direccion=" + direccion + ", telefono=" + telefono + ", correo=" + correo + ", fecha_nac=" + fecha_nac + ", ingresos=" + ingresos + ", score_crediticio=" + score_crediticio + ", ID=" + ID + ", plan_accion=" + plan_accion + ", presupuesto=" + presupuesto + '}';
    }


   
    
    
}
