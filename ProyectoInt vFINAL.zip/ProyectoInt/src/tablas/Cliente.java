/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tablas;

import java.util.Date;

/**
 *
 * @author gian_
 */
public class Cliente {
    private String nombre_cliente;
    private int DNI;
    private String direccion;
    private String telefono;
    private String correo;
    private Date fecha_nac;
    private float ingresos;
    private int score_crediticio;

    public Cliente() {
        this.nombre_cliente = "";
        this.DNI = 0;
        this.direccion = "";
        this.telefono = "";
        this.correo = "";
        this.fecha_nac = new Date();
        this.ingresos = 0;
        this.score_crediticio = 0;
        
        
    }
    
    

    public Cliente(String nombre_cliente, int DNI, String direccion, String telefono, String correo, Date fecha_nac, float ingresos, int score_crediticio) {
        this.nombre_cliente = nombre_cliente;
        this.DNI = DNI;
        this.direccion = direccion;
        this.telefono = telefono;
        this.correo = correo;
        this.fecha_nac = fecha_nac;
        this.ingresos = ingresos;
        this.score_crediticio = score_crediticio;
    }
    



    public int getDNI() {
        return DNI;
    }

    public String getNombre_cliente() {
        return nombre_cliente;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public Date getFecha_nac() {
        return fecha_nac;
    }

    public float getIngresos() {
        return ingresos;
    }

    public int getScore_crediticio() {
        return score_crediticio;
    }

    public void setDNI(int DNI) {
        this.DNI = DNI;
    }

    public void setNombre(String nombre) {
        this.nombre_cliente = nombre;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setFecha_nac(Date fecha_nac) {
        this.fecha_nac = fecha_nac;
    }

    public void setIngresos(float ingresos) {
        this.ingresos = ingresos;
    }

    public void setScore_crediticio(int score_crediticio) {
        this.score_crediticio = score_crediticio;
    }
    
    

    
    
    
    
    
    
    
}
